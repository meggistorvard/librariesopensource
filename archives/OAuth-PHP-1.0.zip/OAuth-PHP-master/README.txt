OAuth-PHP
=========

OAuth 1 PHP library which implements both server and client.

Based on http://oauth.googlecode.com/svn/code/php. Some improvements made by
Pelle Wessman <voxpelli@341713.no-reply.drupal.org> with support from the Drupal
Community.

Used by http://drupal.org/project/oauth
