// This list may be created by a server logic page PHP/ASP/ASPX/JSP in some backend system.
// There links will be displayed as a dropdown in all link dialogs if the "external_link_list_url"
// option is defined in TinyMCE init.

var tinyMCELinkList = new Array(
	// Name, URL
	["Moxiecode", "http://www.moxiecode.com"],
	["Freshmeat", "http://www.freshmeat.com"],
	["Sourceforge", "http://www.sourceforge.com"]
);
